const express = require('express');
const router = express.Router();
const { api, normalizeAxiosError } = require('../services/fergusApi');

// Create a quote with line items (materials & labor)
router.post('/', async (req, res) => {
  try {
    const {
      customerId,
      jobId, // optional: link to job
      reference,
      issueDate, // ISO date
      lineItems = [], // [{ type: 'MATERIAL'|'LABOR', code, description, qty, unitPrice, taxRate }]
      notes
    } = req.body;

    const payload = { customerId, jobId, reference, issueDate, lineItems, notes };
    const r = await api.post('/quotes', payload);
    res.status(201).json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// List quotes
router.get('/', async (req, res) => {
  try {
    const r = await api.get('/quotes', { params: req.query });
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// Get a quote
router.get('/:quoteId', async (req, res) => {
  try {
    const r = await api.get(`/quotes/${req.params.quoteId}`);
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

module.exports = router;
