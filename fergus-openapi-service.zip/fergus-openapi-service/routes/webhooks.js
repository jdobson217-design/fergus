const express = require('express');
const crypto = require('crypto');
const axios = require('axios');
const router = express.Router();

const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || 'changeme';

function verifySignature(req) {
  const signature = req.headers['x-fergus-signature'];
  const body = JSON.stringify(req.body);
  const hash = crypto.createHmac('sha256', WEBHOOK_SECRET).update(body).digest('hex');
  return signature === hash;
}

// Receive Fergus webhooks
router.post('/fergus', async (req, res) => {
  try {
    if (!verifySignature(req)) {
      return res.status(401).json({ error: 'Invalid signature' });
    }

    const eventType = req.headers['x-fergus-event'] || 'unknown';
    const payload = req.body;

    console.log(`[FERGUS EVENT] ${eventType}`, payload);

    switch (eventType) {
      case 'job.created':
        if (process.env.WEBHOOK_FORWARD_URL) {
          await axios.post(process.env.WEBHOOK_FORWARD_URL, {
            text: `⚡ *New Job Created*\n*Title:* ${payload.title}\n*Customer:* ${payload.customer?.name || 'N/A'}\n*Scheduled:* ${payload.scheduledStart} → ${payload.scheduledEnd}\n<https://app.fergus.com/jobs/${payload.id}|View in Fergus>`
          });
        }
        break;
      case 'invoice.paid':
        if (process.env.WEBHOOK_FORWARD_URL) {
          await axios.post(process.env.WEBHOOK_FORWARD_URL, {
            text: `✅ *Invoice Paid*\n*Invoice:* ${payload.id}\n*Customer:* ${payload.customer?.name || 'N/A'}\n*Total:* ${payload.total}\n<https://app.fergus.com/invoices/${payload.id}|View in Fergus>`
          });
        }
        break;
      default:
        console.log('Unhandled Fergus event', eventType);
    }

    res.json({ ok: true });
  } catch (err) {
    console.error('Webhook error', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Forward custom outbound webhook to other services
router.post('/external', async (req, res) => {
  try {
    const { targetUrl, payload } = req.body;
    const r = await axios.post(targetUrl, payload);
    res.json({ delivered: true, status: r.status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
