const express = require('express');
const router = express.Router();
const { api, normalizeAxiosError } = require('../services/fergusApi');

// Create/schedule a job
router.post('/', async (req, res) => {
  try {
    const {
      customerId,
      title,
      description,
      scheduledStart, // ISO date-time
      scheduledEnd,   // ISO date-time
      assignedUserIds = [],
      siteAddress,
      notes
    } = req.body;

    const payload = {
      customerId,
      title,
      description,
      scheduledStart,
      scheduledEnd,
      assignedUserIds,
      siteAddress,
      notes
    };

    const r = await api.post('/jobs', payload);
    res.status(201).json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// List jobs (supports ?from=?to=?status=)
router.get('/', async (req, res) => {
  try {
    const r = await api.get('/jobs', { params: req.query });
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// Get a single job
router.get('/:jobId', async (req, res) => {
  try {
    const r = await api.get(`/jobs/${req.params.jobId}`);
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

module.exports = router;
