const express = require('express');
const router = express.Router();
const { api, normalizeAxiosError } = require('../services/fergusApi');

// Create an invoice with line items (materials & labor)
router.post('/', async (req, res) => {
  try {
    const {
      customerId,
      jobId,   // optional
      quoteId, // optional (to create-from-quote)
      reference,
      issueDate, // ISO date
      dueDate,   // ISO date
      lineItems = [], // [{ type: 'MATERIAL'|'LABOR', code, description, qty, unitPrice, taxRate }]
      notes
    } = req.body;

    const payload = { customerId, jobId, quoteId, reference, issueDate, dueDate, lineItems, notes };
    const r = await api.post('/invoices', payload);
    res.status(201).json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// List invoices
router.get('/', async (req, res) => {
  try {
    const r = await api.get('/invoices', { params: req.query });
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// Get invoice by id
router.get('/:invoiceId', async (req, res) => {
  try {
    const r = await api.get(`/invoices/${req.params.invoiceId}`);
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

module.exports = router;
