const express = require('express');
const router = express.Router();
const { api, normalizeAxiosError } = require('../services/fergusApi');

// Create a customer
router.post('/', async (req, res) => {
  try {
    const { name, email, phone, billingAddress, siteAddress, notes } = req.body;
    const payload = { name, email, phone, billingAddress, siteAddress, notes };
    const r = await api.post('/customers', payload);
    res.status(201).json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// List customers (basic pagination passthrough)
router.get('/', async (req, res) => {
  try {
    const r = await api.get('/customers', { params: req.query });
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

// Get single customer by ID
router.get('/:customerId', async (req, res) => {
  try {
    const r = await api.get(`/customers/${req.params.customerId}`);
    res.json(r.data);
  } catch (err) {
    res.status((err.response && err.response.status) || 500).json({ error: normalizeAxiosError(err) });
  }
});

module.exports = router;
