# Fergus OpenAPI Service

Node.js microservice that exposes convenient endpoints to create customers, schedule jobs, and manage quotes & invoices (with **materials & labour line items**). Proxies to Fergus's official API using Bearer auth.

## Features
- Create/list customers
- Create/list jobs with **scheduledStart/scheduledEnd**
- Create/list quotes (line items: MATERIAL/LABOR)
- Create/list invoices (line items: MATERIAL/LABOR; optional create-from-quote)
- Slack-formatted webhook notifications
- Nightly cron jobs (summary + Google Sheets export)
- Swagger UI at `/docs`

## Local Dev
```bash
cp .env.example .env
npm i
npm run start
# open http://localhost:10000/docs
```

## Render Deployment
1. Push this repo to GitHub.
2. In Render: **New → Web Service → Connect Repo**.
3. Environment variables:
   - `FERGUS_API_KEY` (secret)
   - `FERGUS_BASE_URL` = `https://api.fergus.com/api/v1`
   - `PORT` = `10000`
   - `WEBHOOK_SECRET` = a shared secret for signature verification
   - `WEBHOOK_FORWARD_URL` = Slack or Zapier webhook (optional)
   - `SHEET_ID` and `GOOGLE_SERVICE_KEY` for Sheets sync (optional)
4. Deploy. Open `/docs` to test.

## Example Payloads
### Create Customer
```json
{
  "name": "Acme Pty Ltd",
  "email": "ops@acme.com",
  "phone": "+61 400 000 000",
  "billingAddress": {"line1":"1 High St","city":"Perth","region":"WA","postcode":"6000","country":"AU"},
  "siteAddress": {"line1":"25 Hay St","city":"Perth","region":"WA","postcode":"6000","country":"AU"},
  "notes": "VIP client"
}
```

### Schedule Job
```json
{
  "customerId": "cust_123",
  "title": "Switchboard upgrade",
  "description": "3-phase board, RCBOs",
  "scheduledStart": "2025-10-25T08:00:00+08:00",
  "scheduledEnd": "2025-10-25T12:00:00+08:00",
  "assignedUserIds": ["tech_42"],
  "siteAddress": {"line1":"25 Hay St","city":"Perth","region":"WA","postcode":"6000","country":"AU"},
  "notes": "Access via rear driveway"
}
```

### Create Quote (Materials & Labour)
```json
{
  "customerId": "cust_123",
  "jobId": "job_456",
  "reference": "Q-2025-010",
  "issueDate": "2025-10-24",
  "lineItems": [
    {"type":"MATERIAL","code":"RCBO20","description":"RCBO 20A","qty":6,"unitPrice":48.00,"taxRate":10},
    {"type":"LABOR","description":"Electrician labour","qty":6,"unitPrice":95.00,"taxRate":10}
  ],
  "notes": "Includes disposal and testing"
}
```

### Create Invoice (from Quote or direct)
```json
{
  "customerId": "cust_123",
  "jobId": "job_456",
  "quoteId": "quote_789",
  "reference": "INV-2025-021",
  "issueDate": "2025-10-28",
  "dueDate": "2025-11-11",
  "lineItems": [
    {"type":"MATERIAL","code":"LED13W","description":"LED downlight 13W","qty":12,"unitPrice":22.50,"taxRate":10},
    {"type":"LABOR","description":"Install & test","qty":8,"unitPrice":95.00,"taxRate":10}
  ],
  "notes": "Thank you for your business"
}
```

## Webhooks
- In Fergus, configure a webhook to `https://<your-service>.onrender.com/webhooks/fergus`.
- Use the same `WEBHOOK_SECRET` in Fergus and your service.
- Slack message formatting is supported via `WEBHOOK_FORWARD_URL`.

## Nightly Syncs
- Render `cronJobs` are defined in `render.yaml`:
  - `nightly-sync`: summary to Slack (optional)
  - `nightly-sheets-sync`: exports Jobs + Invoices to Google Sheets

## Google Sheets Setup
- Create a Service Account & JSON key. Paste JSON into the `GOOGLE_SERVICE_KEY` env var.
- Share the target Google Sheet with the service account email.
- Set `SHEET_ID` to your sheet ID.

## Notes
- Adjust endpoint paths/fields if your Fergus tenant or API version differs.
- Always secure secrets via Render environment variables.
