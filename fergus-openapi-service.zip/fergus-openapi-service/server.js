const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const dotenv = require('dotenv');
const YAML = require('yamljs');
const swaggerUi = require('swagger-ui-express');

dotenv.config();

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(cors());
app.use(helmet());
app.use(morgan('tiny'));

// Health check
app.get('/healthz', (_req, res) => {
  res.json({ ok: true, service: 'fergus-openapi-service', ts: new Date().toISOString() });
});

// API routes
app.use('/customers', require('./routes/customers'));
app.use('/jobs', require('./routes/jobs'));
app.use('/quotes', require('./routes/quotes'));
app.use('/invoices', require('./routes/invoices'));
app.use('/webhooks', require('./routes/webhooks'));

// Swagger UI (serves the OpenAPI yaml)
const swaggerDocument = YAML.load(path.join(__dirname, 'swagger', 'openapi.yaml'));
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument, { explorer: true }));

const PORT = process.env.PORT || 10000;
app.listen(PORT, () => {
  console.log(`fergus-openapi-service listening on :${PORT}`);
});
