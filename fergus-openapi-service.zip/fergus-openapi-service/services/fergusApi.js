const axios = require('axios');
const dotenv = require('dotenv');
dotenv.config();

if (!process.env.FERGUS_API_KEY) {
  console.warn('[WARN] FERGUS_API_KEY not set. Set it in your environment.');
}

const api = axios.create({
  baseURL: process.env.FERGUS_BASE_URL || 'https://api.fergus.com/api/v1',
  headers: {
    Authorization: `Bearer ${process.env.FERGUS_API_KEY || ''}`,
    'Content-Type': 'application/json'
  },
  timeout: 30000
});

function normalizeAxiosError(err) {
  if (err.response) {
    return {
      status: err.response.status,
      data: err.response.data,
      headers: err.response.headers
    };
  }
  return { message: err.message };
}

module.exports = { api, normalizeAxiosError };
