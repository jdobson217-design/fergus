require('dotenv').config();
const { google } = require('googleapis');
const { api } = require('../services/fergusApi');

async function authSheets() {
  const creds = JSON.parse(process.env.GOOGLE_SERVICE_KEY);
  const client = new google.auth.JWT(
    creds.client_email,
    null,
    creds.private_key,
    ['https://www.googleapis.com/auth/spreadsheets']
  );
  await client.authorize();
  return google.sheets({ version: 'v4', auth: client });
}

async function syncFergusData() {
  try {
    const sheets = await authSheets();
    const sheetId = process.env.SHEET_ID;

    console.log('Fetching Fergus data...');
    const jobsRes = await api.get('/jobs', { params: { from: '2025-10-01' } });
    const invRes = await api.get('/invoices', { params: { from: '2025-10-01' } });

    const jobs = jobsRes.data.map(j => [j.id, j.title, j.customer?.name, j.scheduledStart, j.scheduledEnd, j.status]);
    const invoices = invRes.data.map(i => [i.id, i.customer?.name, i.reference, i.issueDate, i.dueDate, i.total]);

    console.log('Updating Google Sheet...');

    await sheets.spreadsheets.values.update({
      spreadsheetId: sheetId,
      range: 'Jobs!A2',
      valueInputOption: 'RAW',
      requestBody: { values: jobs }
    });

    await sheets.spreadsheets.values.update({
      spreadsheetId: sheetId,
      range: 'Invoices!A2',
      valueInputOption: 'RAW',
      requestBody: { values: invoices }
    });

    console.log(`✅ Synced ${jobs.length} jobs and ${invoices.length} invoices to Google Sheets.`);
  } catch (err) {
    console.error('Google Sheets sync failed:', err.message);
  }
}

syncFergusData();
