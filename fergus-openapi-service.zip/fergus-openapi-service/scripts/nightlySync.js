require('dotenv').config();
const axios = require('axios');
const { api } = require('../services/fergusApi');

(async () => {
  console.log('Running nightly Fergus sync...');

  try {
    const jobs = await api.get('/jobs', { params: { from: '2025-10-01' } });
    const invoices = await api.get('/invoices', { params: { from: '2025-10-01' } });

    if (process.env.WEBHOOK_FORWARD_URL) {
      await axios.post(process.env.WEBHOOK_FORWARD_URL, {
        text: `🌙 *Nightly Fergus Sync Complete*\nJobs: ${jobs.data.length}\nInvoices: ${invoices.data.length}\nTime: ${new Date().toLocaleString()}`
      });
    }

    console.log('Nightly sync completed successfully.');
  } catch (err) {
    console.error('Sync failed:', err.message);
  }
})();
